#Install and load all the packages
install.packages("lubridate")
install.packages("tidyr")
install.packages("ggplot2")
install.packages("dplyr")
library(lubridate)
library(tidyr) 
library(ggplot2)
library(dplyr)

#Read the csv file with headers

uberData <- read.csv("Uber Request Data.csv",header = TRUE,stringsAsFactors = FALSE)
str(uberData)

#DataCleaning
#1) Change the date format to dd/mm/yyyy HH:MM:SS


uberData$Request.timestamp <- parse_date_time(uberData$Request.timestamp, c("%d-%m-%Y %H:%M:%S", "%d-%m-%Y %H:%M"))


#2) Separate the date column
uberData <-separate(uberData,Request.timestamp, c("Req_Date","Req_Time"), sep = " ", remove=TRUE)

#3)Remving unwanted column
uberData$Driver.id <- NULL
uberData$Drop.timestamp <- NULL

#4)Add timing like early morning etc as a new column to dataframe
uberData$Timing <- NA

#)EarlyMorning
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("05:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("08:00:00","%H:%M:%S"), "EarlyMorning[5-8]")
#)Morning
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("08:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("11:00:00","%H:%M:%S"), "Morning[8-11]")

#)LateMorning
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("11:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("12:00:00","%H:%M:%S"), "LateMorning[11-12]")

#)AfterNoon
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("12:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("17:00:00","%H:%M:%S"), "AfterNoon[12-17]")

#)EarlyEvening
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("17:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("19:00:00","%H:%M:%S"), "EarlyEvening[17-19]")
#)Evening
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("19:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("20:00:00","%H:%M:%S"), "Evening[19-20]")
#)LateEvening
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("20:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("21:00:00","%H:%M:%S"), "LateEvening[20-21]")
#)EarlyNight
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("21:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("23:00:00","%H:%M:%S"), "EarlyNight[21-23]")
#)Night
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("23:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("24:00:00","%H:%M:%S"), "Night[23-24]")
#)Late Night
uberData$Timing <- replace(uberData$Timing, strptime(uberData$Req_Time, "%H:%M:%S") >= strptime("00:00:00","%H:%M:%S") 
                           & strptime(uberData$Req_Time,"%H:%M:%S") < strptime("05:00:00","%H:%M:%S"), "LateNight[00-05]")

#3)Adding demand and supply column
uberData$DemandSupply <- NA

#)Demand
uberData$DemandSupply <- replace(uberData$DemandSupply, uberData$Status == "No Cars Available" | uberData$Status== "Cancelled", "Demand")

#)Demand
uberData$DemandSupply <- replace(uberData$DemandSupply, uberData$Status == "Trip Completed", "Supply")
write.csv(uberData, "UberStudy.csv")

#Data Processing

#Plot to show frequency of booking where booking of each status
plot1 <- ggplot(uberData, aes(x = Status, y =Request.id, fill = Pickup.point)) + ggtitle("Frequency of Requests")+geom_bar(stat = "summary" , fun.y = length)
plot1

#Total number of trips where trip was cancelled or No cars available - 3914
no_car_available <- subset(uberData , (Status == "No Cars Available"))
length(car_not_available$Request.id)

car_cancelled <- subset(uberData , (Status == "Cancelled"))
length(car_cancelled$Request.id)

trip_completed <- subset(uberData , (Status == "Trip Completed"))
length(trip_completed$Request.id)


car_not_available <- subset(uberData , (Status == "No Cars Available" | Status == "Cancelled"))
length(car_not_available$Request.id)
#Total number of trips where Cars not available from airport -1911
car_not_avail_AtAirport <- subset(car_not_available , car_not_available$Pickup.point == "Airport")
length(car_not_avail_AtAirport$Request.id)

#Most problamatic timezone
avail_AtAirpot_groupby_timing<- aggregate(car_not_avail_AtAirport$Timing, by=list(Category=car_not_avail_AtAirport$Timing), FUN=length)
avail_AtAirpot_groupby_timing <- arrange(avail_AtAirpot_groupby_timing, desc(avail_AtAirpot_groupby_timing$x))
avail_AtAirpot_groupby_timing[1,]
#So the most problematic time zone is Early evening that is time between 5 PM to 7 PM when the cabs are not available from airport


#Total number of trips where Cars not available to airport - 2003
car_not_avail_ToAirport<- subset(car_not_available , car_not_available$Pickup.point == "City")
car_not_avail_ToAirport
length(car_not_avail_ToAirport$Request.id)

#Most problamatic timezone
avail_ToAirpot_groupby_timing<- aggregate(car_not_avail_ToAirport$Timing, by=list(Category=car_not_avail_ToAirport$Timing), FUN=length)
avail_ToAirpot_groupby_timing <- arrange(avail_ToAirpot_groupby_timing, desc(avail_ToAirpot_groupby_timing$x))
avail_ToAirpot_groupby_timing[1,]
#So the most problematic time zone is Early morning that is time between 5 AM to 8 AM when the cabs are not available to airport


#There is not much difference between number of trips where Cars not available from airport and 
#number of trips where Cars not available to airport

#Plot to show most problematic types of requests and the time slots

most_problematic_region <- ggplot(car_not_available, aes(x = Timing, y = Request.id,fill = Pickup.point)) + ggtitle("Most Problematic Region")
most_problematic_region <- most_problematic_region + geom_bar(stat = "summary", position = "stack",fun.y = length)
most_problematic_region

#2)
#Supply in each time slot
supply_request <- subset(uberData, uberData$DemandSupply == "Supply")
supply<- aggregate(supply_request$DemandSupply, by=list(Category=supply_request$Timing), FUN=length)
supply <- arrange(supply, desc(supply$x))
supply


#Demand in each time slot
demand_request <- subset(uberData, uberData$DemandSupply == "Demand")
demand<- aggregate(demand_request$DemandSupply, by=list(Category=demand_request$Timing), FUN=length)
demand <- arrange(demand, desc(demand$x))
demand

#SupplyDemandGap

Merge<- merge(demand,supply,by="Category")
Merge$Gap <- Merge$x.x - Merge$x.y
Merge$x.x <- NULL
Merge$x.y <- NULL
Merge <- arrange(Merge, desc(Merge$Gap))
Merge[1,]

#So the most problematic time is Early evening where the gap is maximum

#Graph to show the same, the difference is highest in early evening slot.
time_slot_with_gap <- ggplot(uberData, aes(x = Timing, y = Request.id,fill = DemandSupply)) + ggtitle("Time Slots with gap")
time_slot_with_gap <- time_slot_with_gap + geom_bar(stat = "summary", position = "stack",fun.y = length)
time_slot_with_gap

#Creating subset to only have request at early evening
requestType_in_gap <- subset(uberData, uberData$Timing== "EarlyEvening[17-19]")
#From this creating a subset with all request that are in supply
requestType_in_gap_supply <- subset(requestType_in_gap, requestType_in_gap$DemandSupply== "Supply")
#Similarly doing for demand
requestType_in_gap_demand <- subset(requestType_in_gap, requestType_in_gap$DemandSupply== "Demand")

#Calculating total request created from and to airport
requestType_in_gap_supply_sort<- aggregate(requestType_in_gap_supply$Request.id, 
                                           by=list(Category=requestType_in_gap_supply$Pickup.point), FUN=length)
requestType_in_gap_supply_sort <- arrange(requestType_in_gap_supply_sort, desc(requestType_in_gap_supply_sort$x))
requestType_in_gap_supply_sort

requestType_in_gap_demand_sort<- aggregate(requestType_in_gap_demand$Request.id, 
                                           by=list(Category=requestType_in_gap_demand$Pickup.point), FUN=length)
requestType_in_gap_demand_sort <- arrange(requestType_in_gap_demand_sort, desc(requestType_in_gap_demand_sort$x))
requestType_in_gap_demand_sort

#Mering these two tables and calculating the gap
merge_requestType<- merge(requestType_in_gap_demand_sort,requestType_in_gap_supply_sort,by="Category")
merge_requestType$Gap <- merge_requestType$x.x - merge_requestType$x.y
merge_requestType$x.x <- NULL
merge_requestType$x.y <- NULL
merge_requestType <- arrange(merge_requestType, desc(merge_requestType$Gap))
merge_requestType[1,]

#Graph to show the same thing
time_slot_with_requestType <- ggplot(requestType_in_gap, aes(x = Pickup.point, y = Request.id,fill = DemandSupply)) + ggtitle("Pick Up with gap")
time_slot_with_requestType <- time_slot_with_requestType + geom_bar(stat = "summary", position = "stack",fun.y = length)
time_slot_with_requestType
